//
//  SecondViewController.swift
//  NavigationBar
//
//  Created by Lenovo on 06/02/21.
//

import UIKit

class SecondViewController: UIViewController {
    var displayView = UIScrollView()
    var movieViewTapGstr:UITapGestureRecognizer!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        display()
        components()
        print("Bollywood in second view controller")
        
    }
    //creating a function to displayView to for view
    func display(){
        displayView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height-175)
        displayView.layer.cornerRadius = 50
        displayView.backgroundColor = .lightGray
        view.addSubview(displayView)
    }
    
    func components(){
        var val = 0
        if convertedData != nil{
        for i in 0..<convertedData!.count{
            if convertedData![i].industry == "Bollywood"{
                var posterImages = URLSession.shared.dataTask(with: URL(string: "https://services.brninfotech.com//tws/\(convertedData![i].posters![0].replacingOccurrences(of: " ", with: "%20"))")!) { (data, res, err) in
                    //thread error handling
                    DispatchQueue.main.async {
                        var movieDataView = UIView()
                        movieDataView.frame = CGRect(x: 30, y: 90+val+20, width: 350, height: 240)
                        movieDataView.backgroundColor = .white
                        movieDataView.layer.cornerRadius = 30
                        movieDataView.tag = i
                        self.movieViewTapGstr = UITapGestureRecognizer(target: self, action: #selector(self.movieViewTapAction(sender:)))
                        movieDataView.addGestureRecognizer(self.movieViewTapGstr)
                        self.displayView.addSubview(movieDataView)
                        //creating a label to display movie title
                        var movieTitleLbl = UILabel()
                        movieTitleLbl.frame = CGRect(x: 180, y: 20, width: 150, height: 80)
                        movieTitleLbl.font = UIFont(name: "Rockwell-Bold", size: 22)
                        movieTitleLbl.text = "\(convertedData![i].title!)"
                        movieTitleLbl.textColor = .black
                        movieTitleLbl.numberOfLines = 0
                        movieDataView.addSubview(movieTitleLbl)
                        //creating a label to display movie actors name
                        var movieActorsLbl = UILabel()
                        movieActorsLbl.frame = CGRect(x: 180, y: 110, width: 150, height: 50)
                        movieActorsLbl.numberOfLines = 0
                        movieActorsLbl.font = UIFont(name: "Palatino", size: 20)
                        movieActorsLbl.text = "\(convertedData![i].actors![0]),\(convertedData![i].actors![1])"
                        movieDataView.addSubview(movieActorsLbl)
                        //creating imageView to display movie posters
                        moviePosters = UIImageView(image: UIImage(data: data!))
                        moviePosters.frame = CGRect(x: 30, y: 70+val, width: 150, height: 240)
                        moviePosters.clipsToBounds = true
                        moviePosters.layer.cornerRadius = 30
                        moviePosters.tag = i
                        self.displayView.addSubview(moviePosters)
                        self.displayView.contentSize = CGSize(width: self.view.frame.width, height: moviePosters.frame.maxY+50)
                        val+=320
                        
                    }
                }
                posterImages.resume()
            }else{
                print("none")
            }
        }
        }
    }
    //creating a function for movie view and movie poster on tap action
    @objc func movieViewTapAction(sender:UITapGestureRecognizer){
        var bollywoodDetailsVC = (storyboard?.instantiateViewController(identifier: "bdvc"))! as BollywoodMovieDetailsVC
        bollywoodDetailsVC.displyMovieDetailsInBWVC = convertedData![sender.view!.tag]
        bollywoodDetailsVC.modalTransitionStyle = .coverVertical
        navigationController?.pushViewController(bollywoodDetailsVC, animated: true)
        print("Navigated to bollywood details Vc")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
