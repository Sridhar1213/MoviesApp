//
//  TollywoodMovieDetailsVC.swift
//  NavigationBar
//
//  Created by Lenovo on 07/02/21.
//

import UIKit
import AVKit
import AVFoundation
class TollywoodMovieDetailsVC: UIViewController {
    var displyMovieDetails:MoviesDetailsRootClass?
    var detailsScrollView = UIScrollView()
    var topImage = UIImageView()
    var titleLbl:UILabel!
    var movieTrailerAVPlayerVC = AVPlayerViewController()
    var movieInfoview = UIView()
    var movieInfoScrollView = UIScrollView()
    var movieInfoSwipeUpGstr = UISwipeGestureRecognizer()
    var movieInfoSwipeDownGstr = UISwipeGestureRecognizer()
    var songsInfoView = UIView()
    var songsInfoScrollView = UIScrollView()
    var songsInfoSwipeUpGstr = UISwipeGestureRecognizer()
    var songsInfoSwipeDownGstr = UISwipeGestureRecognizer()
    var movieInfoLbl = UILabel()
    var songsInfoLbl = UILabel()
    var actorsLbl = UILabel()
    var directorLbl = UILabel()
    var industryLbl = UILabel()
    var storyLbl = UILabel()
    var songsView:UIView!
    var songImg:UIImageView!
    var songsLbl:UILabel!
    var playSongwithoutControls:AVPlayerViewController!
    var songWithoutControlsArr = [AVPlayerViewController]()
    var songsViewArr = [UIView]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        componentsInTMDVC()
    }
    //creating a function to create components in this VC
    func componentsInTMDVC(){
        //creating a scroll view for this VC
        detailsScrollView.frame = CGRect(x: 0, y: -50, width: view.frame.width, height: view.frame.height-85)
        detailsScrollView.backgroundColor = view.backgroundColor
        detailsScrollView.layer.cornerRadius = 50
        view.addSubview(detailsScrollView)
        //creating a title label to display movie title
        titleLbl = UILabel()
        titleLbl.font = UIFont(name: "Optima-BoldItalic", size: 35)
        titleLbl.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 250)
        titleLbl.textAlignment = .center
        titleLbl.text = "\(displyMovieDetails!.title!)"
        titleLbl.clipsToBounds = true
        titleLbl.backgroundColor = view.backgroundColor
        titleLbl.layer.cornerRadius = 50
        titleLbl.textColor = .white
        titleLbl.numberOfLines = 0
        detailsScrollView.addSubview(titleLbl)
        //creating trailer AVPVC frame to display movie trailer
        movieTrailerAVPlayerVC.view.frame = CGRect(x: 30, y: 200, width: 350, height: 300)
        movieTrailerAVPlayerVC.view.layer.cornerRadius = 20
        movieTrailerAVPlayerVC.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetails!.trailers![0].replacingOccurrences(of: " ", with: "%20"))")!)
        detailsScrollView.addSubview(movieTrailerAVPlayerVC.view)
        //creating movie info view to display movie info
        movieInfoview.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
        movieInfoview.layer.cornerRadius = 50
        movieInfoview.backgroundColor = .white
        //creating swipe up action and swipe up guester
        movieInfoSwipeUpGstr = UISwipeGestureRecognizer(target: self, action: #selector(movieInfoSwipeUpAction))
        movieInfoSwipeUpGstr.direction = .up
        movieInfoview.addGestureRecognizer(movieInfoSwipeUpGstr)
        //creating swipe down action and swipe down guester
        movieInfoSwipeDownGstr = UISwipeGestureRecognizer(target: self, action: #selector(movieInfoSwipeDownActio))
        movieInfoSwipeDownGstr.direction = .down
        movieInfoview.addGestureRecognizer(movieInfoSwipeDownGstr)
        detailsScrollView.addSubview(movieInfoview)
        //creating movie info scroll view to display movie info
        movieInfoScrollView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 900)
        movieInfoScrollView.layer.cornerRadius = 50
        movieInfoScrollView.backgroundColor = .white
        movieInfoview.addSubview(movieInfoScrollView)
        //creating movie info label
        movieInfoLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 100)
        movieInfoLbl.textColor = view.backgroundColor
        movieInfoLbl.textAlignment = .center
        movieInfoLbl.text = "Movie Info"
        movieInfoLbl.font = UIFont(name: movieInfoLbl.font.fontName, size: 30)
        movieInfoview.addSubview(movieInfoLbl)
        //creating songs info view
        songsInfoView.frame = CGRect(x: 0, y: 685, width: view.frame.width+70, height: 500)
        songsInfoView.layer.cornerRadius = 50
        songsInfoView.backgroundColor = .systemBlue
        detailsScrollView.addSubview(songsInfoView)
        //creating songs view info scroll view to display components and movie songs data
        songsInfoScrollView.frame = CGRect(x: 0, y: 80, width: view.frame.width, height: 500)
        //songsInfoScrollView.contentSize = CGSize(width: view.frame.width, height: 1500)
        songsInfoScrollView.layer.cornerRadius = 50
        songsInfoScrollView.backgroundColor = .systemBlue
        //creating swipe up action and swipe up guester
        songsInfoSwipeUpGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeUpAction))
        songsInfoSwipeUpGstr.direction = .up
        songsInfoView.addGestureRecognizer(songsInfoSwipeUpGstr)
        //creating swipe down action and swipe down guester
        songsInfoSwipeDownGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeDownActio))
        songsInfoSwipeDownGstr.direction = .down
        songsInfoView.addGestureRecognizer(songsInfoSwipeDownGstr)
        songsInfoView.addSubview(songsInfoScrollView)
        //creating songs view info label
        songsInfoLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 60)
        songsInfoLbl.backgroundColor = .systemBlue
        songsInfoLbl.text = "Movie Songs"
        songsInfoLbl.font = UIFont(name: songsInfoLbl.font.fontName, size: 30)
        songsInfoLbl.textAlignment = .center
        songsInfoLbl.textColor = .white
        songsInfoView.addSubview(songsInfoLbl)
        //creating actors label to display actors name
        actorsLbl.frame = CGRect(x: 30, y: 70, width: view.frame.width, height: 100)
      
        
        //error handling if actors unavailable
        if displyMovieDetails!.actors != nil{
            actorsLbl.text = "Cast : \(displyMovieDetails!.actors!)".replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "").replacingOccurrences(of: "\"", with: " ")
        }else{
        
            actorsLbl.text = "Cast : \(displyMovieDetails!.title!) actors unavailable"
        }
        actorsLbl.textColor = .black
        actorsLbl.numberOfLines = 0
        movieInfoScrollView.addSubview(actorsLbl)
        //creating director label to display directors name
        directorLbl.frame = CGRect(x: 30, y: 170, width: view.frame.width, height: 50)
        directorLbl.textColor = .black
        //error handling if director is unavailable
        if displyMovieDetails!.director != nil{
            directorLbl.text = "Director : \(displyMovieDetails!.director!)"
        }else{
            directorLbl.text = "Director : \(displyMovieDetails!.title!) director is unavailable"
        }
        movieInfoScrollView.addSubview(directorLbl)
        //creating industry label to display industry name
        industryLbl.frame = CGRect(x: 30, y: 230, width: view.frame.width, height: 50)
        industryLbl.textColor = .black
        //error handling if industry is unavailabel
        if displyMovieDetails!.industry != nil{
            industryLbl.text = "Industry : \(displyMovieDetails!.industry!)"
        }else{
            industryLbl.text = "Industry : \(displyMovieDetails!.title!) is unavailable"
        }
        movieInfoScrollView.addSubview(industryLbl)
        //creating story label to display movie story
        storyLbl.frame = CGRect(x: 30, y: 290, width: 380, height: 400)
        storyLbl.textColor = .black
        storyLbl.numberOfLines = 0
        //storyLbl.contentMode = .scaleToFill
        //storyLbl.sizeToFit()
        //error handling if movie story is unavailable
        if displyMovieDetails!.story != nil{
            storyLbl.text = "Story : \(displyMovieDetails!.story!)"
        }else{
            storyLbl.text = "Story : \(displyMovieDetails!.title!) story is unavailable"
        }
        movieInfoScrollView.contentSize = CGSize(width: view.frame.width, height: storyLbl.frame.maxY)
        movieInfoScrollView.addSubview(storyLbl)
        //creatings songsView to display movie songs
        //creating a variable to increment view frame
        var val = 0
        for i in 0..<displyMovieDetails!.songs!.count{
            songsView = UIView()
            songsView.frame = CGRect(x: 10, y: 30+val, width: 390, height: 80)
            songsView.backgroundColor = .white
            songsView.layer.cornerRadius = 13
            songsInfoScrollView.addSubview(songsView)
            songsViewArr.append(songsView)
            val+=120
            //adding posters to songsImage
            var songPosterObj = URLSession.shared.dataTask(with:URL(string:"https://services.brninfotech.com/tws/\( displyMovieDetails!.posters![0])".replacingOccurrences(of: " ", with: "%20"))!) { (posters, res1, err1) in
                print("\(posters) hsgjgjgsdggdgsdggsggsgsg")
                if posters != nil{
                    DispatchQueue.main.async {
                        //creating songs image for displaying in details view controller
                        self.songImg = UIImageView(image: UIImage(data: posters!))
                        self.songImg.frame = CGRect(x: 20, y: 10, width: 50, height: 50)
                        self.songImg.contentMode = .scaleToFill
                        self.songsViewArr[i].addSubview(self.songImg)
                }
                }else{
                    print("posters are nil")
                }

            }
            //resuming songPosterObj
            songPosterObj.resume()
//        }else{
//
//        }
//            //creating songLbl for displaying song name
            songsLbl = UILabel()
            songsLbl.frame = CGRect(x: 90, y: 15, width: 230, height: 50)
            songsLbl.text = "\(displyMovieDetails!.songs![i].split(separator: "/")[3])"
            songsLbl.textColor = view.backgroundColor
            songsView.addSubview(songsLbl)
            //creating AVPlayerViewController without controls
            playSongwithoutControls = AVPlayerViewController()
            playSongwithoutControls.view.frame = CGRect(x: 310, y: 15, width: 60, height: 50)
            playSongwithoutControls.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetails!.songs![i])".replacingOccurrences(of: " ", with: "%20"))!)

            playSongwithoutControls.view.backgroundColor = .white
            
            songsView.addSubview(playSongwithoutControls.view)
            songWithoutControlsArr.append(playSongwithoutControls)

            
        }
        songsInfoScrollView.contentSize = CGSize(width: view.frame.width, height: songsView.frame.maxY+100)
    }
    //creating swipe gesture action to movie info view
    @objc func movieInfoSwipeUpAction(){
        //changing view frame based on swipe up action
        if movieInfoSwipeUpGstr.direction == .up{
            movieInfoview.frame = CGRect(x: 0, y: 160, width: view.frame.width+50, height: 900)
            print("swiped up")
        }
    }
    //creating swipe down guester action to movie info view
    @objc func movieInfoSwipeDownActio(){
        //changing view frame based on swipe down action
        if movieInfoSwipeDownGstr.direction == .down{
            movieInfoview.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
            print("swiped down")
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeUpAction(){
        //changing view frame based on swipe up action
        if songsInfoSwipeUpGstr.direction == .up{
            songsInfoView.frame = CGRect(x: 0, y: 245, width: view.frame.width+50, height: 900)
            print("swiped up")
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeDownActio(){
        //changing view frame based on swipe down action
        if songsInfoSwipeDownGstr.direction == .down{
            songsInfoView.frame = CGRect(x: 0, y: 685, width: view.frame.width+50, height: 900)
            print("swiped down")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
