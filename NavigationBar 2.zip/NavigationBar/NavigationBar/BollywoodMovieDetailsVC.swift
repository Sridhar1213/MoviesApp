//
//  BollywoodMovieDetailsVC.swift
//  NavigationBar
//
//  Created by Lenovo on 07/02/21.
//

import UIKit
import AVKit
import AVFoundation
class BollywoodMovieDetailsVC: UIViewController {
    var displyMovieDetailsInBWVC:MoviesDetailsRootClass?
    var bollywoodScrollView = UIScrollView()
    var bwTitleLbl = UILabel()
    var bwTrailerVC = AVPlayerViewController()
    var bwMovieInfoView = UIView()
    var bwMovieInfoViewSwipeUpGstr = UISwipeGestureRecognizer()
    var bwMovieInfoViewSwipeDownGstr = UISwipeGestureRecognizer()
    var bwSongsViewSwipeUpGstr = UISwipeGestureRecognizer()
    var bwSongsViewSwipeDownGstr = UISwipeGestureRecognizer()
    var bwMovieInfoSC = UIScrollView()
    var bwMovieInfoLbl = UILabel()
    var bwMovieSongsView = UIView()
    var bwSongsScrollView = UIScrollView()
    var bwMovieSongsLbl = UILabel()
    var bwMovieActorsLbl = UILabel()
    var bwMovieDirectorLbl = UILabel()
    var bwMovieIndustryLbl = UILabel()
    var bwMovieStoryLbl = UILabel()
    var bwSongsView = UIView()
    var bwMovieSongsImage:UIImageView!
    var bwSongsLbl:UILabel!
    var bwSongswithoutControls:AVPlayerViewController!
    var bwSongswithoutControlsArr = [AVPlayerViewController]()
    var bwSongsViewArr = [UIView]()
    override func viewDidLoad() {
        super.viewDidLoad()
        populatingDataInBMDVC()
        // Do any additional setup after loading the view.
    }
    //creating populatingDataInBMDVC func to display data of movies
    func populatingDataInBMDVC(){
        //creating bollywoodScrollView to display components
        bollywoodScrollView.frame = CGRect(x: 0, y: -50, width: view.frame.width, height: view.frame.height-85)
        bollywoodScrollView.backgroundColor = view.backgroundColor
        bollywoodScrollView.layer.cornerRadius = 50
        view.addSubview(bollywoodScrollView)
        //creating bwTitleLbl to display bollywood movie title
        bwTitleLbl.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 250)
        bwTitleLbl.font = UIFont(name: "Optima-BoldItalic", size: 35)
        bwTitleLbl.textAlignment = .center
        bwTitleLbl.text = "\(displyMovieDetailsInBWVC!.title!)"
        bwTitleLbl.clipsToBounds = true
        bwTitleLbl.backgroundColor = view.backgroundColor
        bwTitleLbl.layer.cornerRadius = 50
        bwTitleLbl.textColor = .white
        bwTitleLbl.numberOfLines = 0
        bollywoodScrollView.addSubview(bwTitleLbl)
        //creating bwTrailerVC to display movie trailer
        bwTrailerVC.view.frame = CGRect(x: 30, y: 200, width: 350, height: 300)
        bwTrailerVC.view.layer.cornerRadius = 20
        bwTrailerVC.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetailsInBWVC!.trailers![0].replacingOccurrences(of: " ", with: "%20"))")!)
        bollywoodScrollView.addSubview(bwTrailerVC.view)
        //creating bwMovieInfoView to display movie info
        bwMovieInfoView.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
        bwMovieInfoView.layer.cornerRadius = 50
        bwMovieInfoView.backgroundColor = .white
        //adding swipe up action to bwInfoView
        bwMovieInfoViewSwipeUpGstr.addTarget(self, action: #selector(bwViewInfoSwipeUpAction))
        bwMovieInfoViewSwipeUpGstr.direction = .up
        bwMovieInfoView.addGestureRecognizer(bwMovieInfoViewSwipeUpGstr)
            //adding swipe down action to bwInfoView
        bwMovieInfoViewSwipeDownGstr.addTarget(self, action: #selector(bwViewInfoSwipeDownAction))
        bwMovieInfoViewSwipeDownGstr.direction = .down
        bwMovieInfoView.addGestureRecognizer(bwMovieInfoViewSwipeDownGstr)
        bollywoodScrollView.addSubview(bwMovieInfoView)
        //creating movie info scroll view to display movie info
        bwMovieInfoSC.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 900)
        bwMovieInfoSC.layer.cornerRadius = 50
        bwMovieInfoSC.backgroundColor = .white
        bwMovieInfoView.addSubview(bwMovieInfoSC)
        //creating bwMovieinfoLbl
        bwMovieInfoLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 100)
        bwMovieInfoLbl.textColor = view.backgroundColor
        bwMovieInfoLbl.textAlignment = .center
        bwMovieInfoLbl.text = "Movie Info"
        bwMovieInfoLbl.font = UIFont(name: bwMovieInfoLbl.font.fontName, size: 30)
        bwMovieInfoView.addSubview(bwMovieInfoLbl)
        //creating songs info view
        bwMovieSongsView.frame = CGRect(x: 0, y: 685, width: view.frame.width+70, height: 500)
        bwMovieSongsView.layer.cornerRadius = 50
        bwMovieSongsView.backgroundColor = .systemBlue
        bollywoodScrollView.addSubview(bwMovieSongsView)
        //creating songs view info scroll view to display components and movie songs data
        bwSongsScrollView.frame = CGRect(x: 0, y: 80, width: view.frame.width, height: 500)
        //bwSongsScrollView.contentSize = CGSize(width: view.frame.width, height: 1500)
        bwSongsScrollView.layer.cornerRadius = 50
        bwSongsScrollView.backgroundColor = .systemBlue
        //creating swipe up action and swipe up guester
        bwSongsViewSwipeUpGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeUpAction))
        bwSongsViewSwipeUpGstr.direction = .up
        bwMovieSongsView.addGestureRecognizer(bwSongsViewSwipeUpGstr)
        //creating swipe down action and swipe down guester
        bwSongsViewSwipeDownGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeDownActio))
        bwSongsViewSwipeDownGstr.direction = .down
        bwMovieSongsView.addGestureRecognizer(bwSongsViewSwipeDownGstr)
        bwMovieSongsView.addSubview(bwSongsScrollView)
        //creating bwMovieSongsLbl label
        bwMovieSongsLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 60)
        bwMovieSongsLbl.backgroundColor = .systemBlue
        bwMovieSongsLbl.text = "Movie Songs"
        bwMovieSongsLbl.font = UIFont(name: bwMovieSongsLbl.font.fontName, size: 30)
        bwMovieSongsLbl.textAlignment = .center
        bwMovieSongsLbl.textColor = .white
        bwMovieSongsView.addSubview(bwMovieSongsLbl)
        //creating bwMovieActors label to display actors name
        bwMovieActorsLbl.frame = CGRect(x: 30, y: 70, width: view.frame.width, height: 100)
        //error handling if actors unavailable
        if displyMovieDetailsInBWVC!.actors != nil{
            bwMovieActorsLbl.text = "Cast : \(displyMovieDetailsInBWVC!.actors!)".replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "").replacingOccurrences(of: "\"", with: " ")

        }else{
            bwMovieActorsLbl.text = "Cast : \(displyMovieDetailsInBWVC!.title!) actors unavailable"
        }
        bwMovieActorsLbl.textColor = .black
        bwMovieActorsLbl.numberOfLines = 0
        bwMovieInfoSC.addSubview(bwMovieActorsLbl)
        //creating bwMovieDirector label to display directors name
        bwMovieDirectorLbl.frame = CGRect(x: 30, y: 170, width: view.frame.width, height: 50)
        bwMovieDirectorLbl.textColor = .black
        //error handling if director is unavailable
        if displyMovieDetailsInBWVC!.director != nil{
            bwMovieDirectorLbl.text = "Director : \(displyMovieDetailsInBWVC!.director!)"
        }else{
            bwMovieDirectorLbl.text = "Director : \(displyMovieDetailsInBWVC!.title!) director is unavailable"
        }
        bwMovieInfoSC.addSubview(bwMovieDirectorLbl)
        //creating bwMovieIndustry label to display industry name
        bwMovieIndustryLbl.frame = CGRect(x: 30, y: 230, width: view.frame.width, height: 50)
        bwMovieIndustryLbl.textColor = .black
        //error handling if industry is unavailabel
        if displyMovieDetailsInBWVC!.industry != nil{
            bwMovieIndustryLbl.text = "Industry : \(displyMovieDetailsInBWVC!.industry!)"
        }else{
            bwMovieIndustryLbl.text = "Industry : \(displyMovieDetailsInBWVC!.title!) is unavailable"
        }
        bwMovieInfoSC.addSubview(bwMovieIndustryLbl)
        //creating bwMovieStory label to display movie story
        bwMovieStoryLbl.frame = CGRect(x: 30, y: 290, width: 380, height: 400)
        bwMovieStoryLbl.textColor = .black
        bwMovieStoryLbl.numberOfLines = 0
        //bwMovieStoryLbl.contentMode = .scaleToFill
        //bwMovieStoryLbl.sizeToFit()
        //error handling if movie story is unavailable
        if displyMovieDetailsInBWVC!.story != nil{
            bwMovieStoryLbl.text = "Story : \(displyMovieDetailsInBWVC!.story!)"
        }else{
            bwMovieStoryLbl.text = "Story : \(displyMovieDetailsInBWVC!.title!) story is unavailable"
        }
        bwMovieInfoSC.contentSize = CGSize(width: view.frame.width, height: bwMovieStoryLbl.frame.maxY)
        bwMovieInfoSC.addSubview(bwMovieStoryLbl)
        //creatings songsView to display movie songs
        //creating a variable to increment view frame
        var val = 0
        for i in 0..<displyMovieDetailsInBWVC!.songs!.count{
            //creating bwSongsView to display songs names and songsAVPVC
            bwSongsView = UIView()
            bwSongsView.frame = CGRect(x: 10, y: 30+val, width: 390, height: 80)
            bwSongsView.backgroundColor = .white
            bwSongsView.layer.cornerRadius = 13
            bwSongsScrollView.addSubview(bwSongsView)
            bwSongsViewArr.append(bwSongsView)
            val+=120
            //adding posters to songsImage
            var songPosterObj = URLSession.shared.dataTask(with:URL(string:"https://services.brninfotech.com/tws/\( displyMovieDetailsInBWVC!.posters![0])".replacingOccurrences(of: " ", with: "%20"))!) { (posters, res1, err1) in
                if posters != nil{
                    //thread error handling
                    DispatchQueue.main.async {
                        //creating songs image for displaying in BMDVC view controller
                        self.bwMovieSongsImage = UIImageView(image: UIImage(data: posters!))
                        self.bwMovieSongsImage.frame = CGRect(x: 20, y: 10, width: 50, height: 50)
                        self.bwMovieSongsImage.contentMode = .scaleToFill
                        self.bwSongsViewArr[i].addSubview(self.bwMovieSongsImage)
                }
                }else{
                    print("posters are nil")
                }

            }
            //resuming songPosterObj
            songPosterObj.resume()
//        }else{
//
//        }
//            //creating bwSongsLbl for displaying song name
            bwSongsLbl = UILabel()
            bwSongsLbl.frame = CGRect(x: 90, y: 15, width: 230, height: 50)
            bwSongsLbl.text = "\(displyMovieDetailsInBWVC!.songs![i].split(separator: "/")[3])"
            bwSongsLbl.textColor = view.backgroundColor
            bwSongsView.addSubview(bwSongsLbl)
            //creating AVPlayerViewController without controls
            bwSongswithoutControls = AVPlayerViewController()
            bwSongswithoutControls.view.frame = CGRect(x: 310, y: 15, width: 60, height: 50)
            bwSongswithoutControls.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetailsInBWVC!.songs![i])".replacingOccurrences(of: " ", with: "%20"))!)

            bwSongswithoutControls.view.backgroundColor = .white
            
            bwSongsView.addSubview(bwSongswithoutControls.view)
            bwSongswithoutControlsArr.append(bwSongswithoutControls)
        }
        bwSongsScrollView.contentSize = CGSize(width: view.frame.width, height: bwSongsView.frame.maxY+100)

    }
    //creating bwViewInfoSwipeUpAction function to change view frame
    @objc func bwViewInfoSwipeUpAction(){
        if bwMovieInfoViewSwipeUpGstr.direction == .up{
            bwMovieInfoView.frame = CGRect(x: 0, y: 160, width: view.frame.width+50, height: 900)
        }
    }
    //creating bwViewInfoSwipeUpAction function to change view frame
    @objc func bwViewInfoSwipeDownAction(){
        if bwMovieInfoViewSwipeUpGstr.direction == .up{
            bwMovieInfoView.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeUpAction(){
        //changing view frame based on swipe up action
        if bwSongsViewSwipeUpGstr.direction == .up{
            bwMovieSongsView.frame = CGRect(x: 0, y: 245, width: view.frame.width+50, height: 900)
            print("swiped up")
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeDownActio(){
        //changing view frame based on swipe down action
        if bwSongsViewSwipeDownGstr.direction == .down{
            bwMovieSongsView.frame = CGRect(x: 0, y: 685, width: view.frame.width+50, height: 900)
            print("swiped down")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
