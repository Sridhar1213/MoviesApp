//
//  ThirdViewController.swift
//  NavigationBar
//
//  Created by Lenovo on 07/02/21.
//

import UIKit

class ThirdViewController: UIViewController {
    var othersVCSV = UIScrollView()
    var moviePosters=UIImageView()
    var movieViewTapGstr:UITapGestureRecognizer!
    override func viewDidLoad() {
        super.viewDidLoad()
        display()
        components()
        // Do any additional setup after loading the view.
    }
    //creating a function to displayView to for view
    func display(){
        othersVCSV.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height-175)
        othersVCSV.layer.cornerRadius = 50
        othersVCSV.backgroundColor = .lightGray
        view.addSubview(othersVCSV)
    }
    
    func components(){
        var val = 0
        if convertedData != nil{
        for i in 0..<convertedData!.count{
            print(convertedData!.count)
            print(convertedData![i].title!)
            print(convertedData![i].industry)
            if convertedData![i].industry != "Tollywood" && convertedData![i].industry != "Bollywood"{
            var posterImages = URLSession.shared.dataTask(with: URL(string: "https://services.brninfotech.com//tws/\(convertedData![i].posters![0].replacingOccurrences(of: " ", with: "%20"))")!) { (data, res, err) in
                //print(data)
                //thread error handling
                    DispatchQueue.main.async {
                        var movieDataView = UIView()
                        movieDataView.frame = CGRect(x: 30, y: 90+val+20, width: 350, height: 240)
                        movieDataView.backgroundColor = .white
                        movieDataView.layer.cornerRadius = 30
                        movieDataView.tag = i
                        self.movieViewTapGstr = UITapGestureRecognizer(target: self, action: #selector(self.movieViewTapAction(sender:)))
                        movieDataView.addGestureRecognizer(self.movieViewTapGstr)
                        self.othersVCSV.addSubview(movieDataView)
                        //creating a label to display movie title
                        var movieTitleLbl = UILabel()
                        movieTitleLbl.frame = CGRect(x: 180, y: 20, width: 150, height: 80)
                        movieTitleLbl.font = UIFont(name: "Rockwell-Bold", size: 22)
                        movieTitleLbl.text = "\(convertedData![i].title!)"
                        movieTitleLbl.textColor = .black
                        movieTitleLbl.numberOfLines = 0
                        movieDataView.addSubview(movieTitleLbl)
                        //creating a label to display movie actors name
                        var movieActorsLbl = UILabel()
                        movieActorsLbl.frame = CGRect(x: 180, y: 110, width: 150, height: 50)
                        movieActorsLbl.numberOfLines = 0
                        movieActorsLbl.font = UIFont(name: "Palatino", size: 20)
                        movieActorsLbl.text = "\(convertedData![i].actors![0]),\(convertedData![i].actors![1])"
                        movieDataView.addSubview(movieActorsLbl)
                        //creating imageView to display movie posters
                        self.moviePosters = UIImageView(image: UIImage(data: data!))
                        self.moviePosters.frame = CGRect(x: 30, y: 70+val, width: 150, height: 240)
                        self.moviePosters.clipsToBounds = true
                        self.moviePosters.layer.cornerRadius = 30
                        self.moviePosters.tag = i
                        self.othersVCSV.addSubview(self.moviePosters)
                        self.othersVCSV.contentSize = CGSize(width: self.view.frame.width, height: self.moviePosters.frame.maxY+50)
                        val+=320
                        
                    }
                }
                posterImages.resume()
            }else{
                print("none")
            }
        }
        }
    }
    //creating a function for movie view and movie poster on tap action
    @objc func movieViewTapAction(sender:UITapGestureRecognizer){
        var othersDetailsVC = (storyboard?.instantiateViewController(identifier: "odvc"))! as OthersMovieDetailsVC
        othersDetailsVC.displyMovieDetailsInOVC = convertedData![sender.view!.tag]
        othersDetailsVC.modalTransitionStyle = .coverVertical
        navigationController?.pushViewController(othersDetailsVC, animated: true)
        print("Navigated to others details Vc")
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
