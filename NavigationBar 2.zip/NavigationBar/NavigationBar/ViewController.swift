//
//  ViewController.swift
//  NavigationBar
//
//  Created by Lenovo on 06/02/21.
//

import UIKit
var urlRequest:URLRequest!
var dataTaskObj:URLSessionDataTask!
var convertedData:[MoviesDetailsRootClass]?
var moviePosters:UIImageView!
var movieNameBtn:UIButton!
class ViewController: UIViewController, UINavigationControllerDelegate {
    var displayView = UIScrollView()
    var movieViewTapGstr:UITapGestureRecognizer!
    
    override func viewDidLoad() {
        
        navigationController?.delegate = self
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //view.backgroundColor = .systemBlue
        display()
        connectToServer()
    }
    //creating a view to display data
    func display(){
        displayView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height-175)
        displayView.layer.cornerRadius = 50
        displayView.backgroundColor = .lightGray
        view.addSubview(displayView)
        
    }
    
    //creating connectToServer function for getting data from server
    func connectToServer(){
        urlRequest = URLRequest(url: URL(string: "https://services.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!)
        urlRequest.httpMethod = "POST"
        dataTaskObj = URLSession.shared.dataTask(with: urlRequest, completionHandler: { (data, response, err) in
            print("Recieved data from movies")
            var jsonDecodeObj = JSONDecoder()
            if err == nil{
            do{
            convertedData = try jsonDecodeObj.decode([MoviesDetailsRootClass].self, from: data!)
            print(convertedData!)
                var val = 0
                //components function contains uicomponents to display data recieved from server
                self.components()
            }catch{
                print("Something went wrong in movies")
            }
        }else{
            print("Not connected to internet")
            DispatchQueue.main.async {
                var label = UILabel()
                label.frame = CGRect(x: 100, y: 200, width: 200, height: 200)
                label.text = "Not internet"
                label.textColor = .white
                label.backgroundColor = self.view.backgroundColor
                self.displayView.addSubview(label)
            }
        }
        })
        dataTaskObj.resume()
    }
    //creating componenets function for displaying components
    func components(){
        var val = 0
        for i in 0..<convertedData!.count{
            if convertedData![i].industry == "Tollywood"{
            var posterImages = URLSession.shared.dataTask(with: URL(string: "https://services.brninfotech.com//tws/\(convertedData![i].posters![0].replacingOccurrences(of: " ", with: "%20"))")!) { (data, res, err) in
                //thread error handling
                DispatchQueue.main.async {
                    var movieDataView = UIView()
                    movieDataView.frame = CGRect(x: 30, y: 90+val+20, width: 350, height: 240)
                    movieDataView.backgroundColor = .white
                    movieDataView.layer.cornerRadius = 30
                    movieDataView.tag = i
                    self.movieViewTapGstr = UITapGestureRecognizer(target: self, action: #selector(self.movieViewTapAction(sender:)))
                    movieDataView.addGestureRecognizer(self.movieViewTapGstr)
                    self.displayView.addSubview(movieDataView)
                    //creating a label to display movie title
                    var movieTitleLbl = UILabel()
                    movieTitleLbl.frame = CGRect(x: 180, y: 20, width: 150, height: 80)
                    movieTitleLbl.font = UIFont(name: "Rockwell-Bold", size: 22)
                    movieTitleLbl.text = "\(convertedData![i].title!)"
                    movieTitleLbl.textColor = .black
                    movieTitleLbl.numberOfLines = 0
                    movieDataView.addSubview(movieTitleLbl)
                    //creating a label to display movie actors name
                    var movieActorsLbl = UILabel()
                    movieActorsLbl.frame = CGRect(x: 180, y: 110, width: 150, height: 50)
                    movieActorsLbl.numberOfLines = 0
                    movieActorsLbl.font = UIFont(name: "Palatino", size: 20)
                    movieActorsLbl.text = "\(convertedData![i].actors![0]),\(convertedData![i].actors![1])"
                    movieDataView.addSubview(movieActorsLbl)
                    //creating imageView to display movie posters
                    moviePosters = UIImageView(image: UIImage(data: data!))
                    moviePosters.frame = CGRect(x: 30, y: 70+val, width: 150, height: 240)
                    moviePosters.clipsToBounds = true
                    moviePosters.layer.cornerRadius = 30
                    moviePosters.tag = i
                    self.displayView.addSubview(moviePosters)
                    self.displayView.contentSize = CGSize(width: self.view.frame.width, height: moviePosters.frame.maxY+50)
                    val+=320
                    
                }
            }
            posterImages.resume()
        }else{
            print("none")
            }
        }
    }
    //creating a function for movie view and movie poster on tap action
    @objc func movieViewTapAction(sender:UITapGestureRecognizer){
        var tollywoodDetailsVC = (storyboard?.instantiateViewController(identifier: "tdvc"))! as TollywoodMovieDetailsVC
        tollywoodDetailsVC.displyMovieDetails = convertedData![sender.view!.tag]
        tollywoodDetailsVC.modalTransitionStyle = .flipHorizontal
        navigationController?.pushViewController(tollywoodDetailsVC, animated: true)
        print("Navigated to tollywood details Vc")
    }
    
    
}

