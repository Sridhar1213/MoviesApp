//
//  OthersMovieDetailsVC.swift
//  NavigationBar
//
//  Created by Lenovo on 07/02/21.
//

import UIKit
import AVKit
import AVFoundation
class OthersMovieDetailsVC: UIViewController {
    var displyMovieDetailsInOVC:MoviesDetailsRootClass?
    var othersScrollView = UIScrollView()
    var othersTitleLbl = UILabel()
    var othersTrailerVC = AVPlayerViewController()
    var othersMovieInfoView = UIView()
    var othersMovieInfoViewSwipeUpGstr = UISwipeGestureRecognizer()
    var othersMovieInfoViewSwipeDownGstr = UISwipeGestureRecognizer()
    var othersSongsViewSwipeUpGstr = UISwipeGestureRecognizer()
    var othersSongsViewSwipeDownGstr = UISwipeGestureRecognizer()
    var othersMovieInfoSC = UIScrollView()
    var othersMovieInfoLbl = UILabel()
    var othersMovieSongsView = UIView()
    var othersSongsScrollView = UIScrollView()
    var othersMovieSongsLbl = UILabel()
    var othersMovieActorsLbl = UILabel()
    var othersMovieDirectorLbl = UILabel()
    var othersMovieIndustryLbl = UILabel()
    var othersMovieStoryLbl = UILabel()
    var othersSongsView:UIView!
    var othersMovieSongsImage:UIImageView!
    var othersSongsLbl:UILabel!
    var othersSongswithoutControls:AVPlayerViewController!
    var othersSongswithoutControlsArr = [AVPlayerViewController]()
    var othersSongsViewArr = [UIView]()
    override func viewDidLoad() {
        super.viewDidLoad()
        populatingDataInOMDVC()
        // Do any additional setup after loading the view.
    }
    func populatingDataInOMDVC(){
        //creating bollywoodScrollView to display components
        othersScrollView.frame = CGRect(x: 0, y: -50, width: view.frame.width, height: view.frame.height-85)
        othersScrollView.backgroundColor = view.backgroundColor
        othersScrollView.layer.cornerRadius = 50
        view.addSubview(othersScrollView)
        //creating othersTitleLbl to display bollywood movie title
        othersTitleLbl.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 250)
        othersTitleLbl.font = UIFont(name: "Optima-BoldItalic", size: 35)
        othersTitleLbl.textAlignment = .center
        othersTitleLbl.text = "\(displyMovieDetailsInOVC!.title!)"
        othersTitleLbl.clipsToBounds = true
        othersTitleLbl.backgroundColor = view.backgroundColor
        othersTitleLbl.layer.cornerRadius = 50
        othersTitleLbl.textColor = .white
        othersTitleLbl.numberOfLines = 0
        othersScrollView.addSubview(othersTitleLbl)
        //creating othersTrailerVC to display movie trailer
        othersTrailerVC.view.frame = CGRect(x: 30, y: 200, width: 350, height: 300)
        othersTrailerVC.view.layer.cornerRadius = 20
        othersTrailerVC.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetailsInOVC!.trailers![0].replacingOccurrences(of: " ", with: "%20"))")!)
        othersScrollView.addSubview(othersTrailerVC.view)
        //creating othersMovieInfoView to display movie info
        othersMovieInfoView.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
        othersMovieInfoView.layer.cornerRadius = 50
        othersMovieInfoView.backgroundColor = .white
        //adding swipe up action to othersInfoView
        othersMovieInfoViewSwipeUpGstr.addTarget(self, action: #selector(othersViewInfoSwipeUpAction))
        othersMovieInfoViewSwipeUpGstr.direction = .up
        othersMovieInfoView.addGestureRecognizer(othersMovieInfoViewSwipeUpGstr)
            //adding swipe down action to othersInfoView
        othersMovieInfoViewSwipeDownGstr.addTarget(self, action: #selector(othersViewInfoSwipeDownAction))
        othersMovieInfoViewSwipeDownGstr.direction = .down
        othersMovieInfoView.addGestureRecognizer(othersMovieInfoViewSwipeDownGstr)
        othersScrollView.addSubview(othersMovieInfoView)
        //creating movie info scroll view to display movie info
        othersMovieInfoSC.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 900)
        othersMovieInfoSC.layer.cornerRadius = 50
        othersMovieInfoSC.backgroundColor = .white
        othersMovieInfoView.addSubview(othersMovieInfoSC)
        //creating othersMovieinfoLbl
        othersMovieInfoLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 100)
        othersMovieInfoLbl.textColor =  view.backgroundColor
        othersMovieInfoLbl.textAlignment = .center
        othersMovieInfoLbl.text = "Movie Info"
        othersMovieInfoLbl.font = UIFont(name: othersMovieInfoLbl.font.fontName, size: 30)
        othersMovieInfoView.addSubview(othersMovieInfoLbl)
        //creating songs info view
        othersMovieSongsView.frame = CGRect(x: 0, y: 685, width: view.frame.width+70, height: 500)
        othersMovieSongsView.layer.cornerRadius = 50
        othersMovieSongsView.backgroundColor = .systemBlue
        othersScrollView.addSubview(othersMovieSongsView)
        //creating songs view info scroll view to display components and movie songs data
        othersSongsScrollView.frame = CGRect(x: 0, y: 80, width: view.frame.width, height: 500)
        //othersSongsScrollView.contentSize = CGSize(width: view.frame.width, height: 1500)
        othersSongsScrollView.layer.cornerRadius = 50
        othersSongsScrollView.backgroundColor = .systemBlue
        //creating swipe up action and swipe up guester
        othersSongsViewSwipeUpGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeUpAction))
        othersSongsViewSwipeUpGstr.direction = .up
        othersMovieSongsView.addGestureRecognizer(othersSongsViewSwipeUpGstr)
        //creating swipe down action and swipe down guester
        othersSongsViewSwipeDownGstr = UISwipeGestureRecognizer(target: self, action: #selector(songsInfoSwipeDownActio))
        othersSongsViewSwipeDownGstr.direction = .down
        othersMovieSongsView.addGestureRecognizer(othersSongsViewSwipeDownGstr)
        othersMovieSongsView.addSubview(othersSongsScrollView)
        //creating othersMovieSongsLbl label
        othersMovieSongsLbl.frame = CGRect(x: 70, y: 0, width: 300, height: 60)
        othersMovieSongsLbl.backgroundColor = .systemBlue
        othersMovieSongsLbl.text = "Movie Songs"
        othersMovieSongsLbl.font = UIFont(name: othersMovieSongsLbl.font.fontName, size: 30)
        othersMovieSongsLbl.textAlignment = .center
        othersMovieSongsLbl.textColor = .white
        othersMovieSongsView.addSubview(othersMovieSongsLbl)
        //creating othersMovieActors label to display actors name
        othersMovieActorsLbl.frame = CGRect(x: 30, y: 70, width: view.frame.width, height: 100)
        //error handling if actors unavailable
        if displyMovieDetailsInOVC!.actors != nil{
            othersMovieActorsLbl.text = "Cast : \(displyMovieDetailsInOVC!.actors!)".replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "").replacingOccurrences(of: "\"", with: " ")
        }else{
            othersMovieActorsLbl.text = "Cast : \(displyMovieDetailsInOVC!.title!) actors unavailable"
        }
        othersMovieActorsLbl.textColor = .black
        othersMovieActorsLbl.numberOfLines = 0
        othersMovieInfoSC.addSubview(othersMovieActorsLbl)
        //creating othersMovieDirector label to display directors name
        othersMovieDirectorLbl.frame = CGRect(x: 30, y: 170, width: view.frame.width, height: 50)
        othersMovieDirectorLbl.textColor = .black
        //error handling if director is unavailable
        if displyMovieDetailsInOVC!.director != nil{
            othersMovieDirectorLbl.text = "Director : \(displyMovieDetailsInOVC!.director!)"
        }else{
            othersMovieDirectorLbl.text = "Director : \(displyMovieDetailsInOVC!.title!) director is unavailable"
        }
        othersMovieInfoSC.addSubview(othersMovieDirectorLbl)
        //creating othersMovieIndustry label to display industry name
        othersMovieIndustryLbl.frame = CGRect(x: 30, y: 230, width: view.frame.width, height: 50)
        othersMovieIndustryLbl.textColor = .black
        //error handling if industry is unavailabel
        if displyMovieDetailsInOVC!.industry != nil{
            othersMovieIndustryLbl.text = "Industry : \(displyMovieDetailsInOVC!.industry!)"
        }else{
            othersMovieIndustryLbl.text = "Industry : \(displyMovieDetailsInOVC!.title!) is unavailable"
        }
        othersMovieInfoSC.addSubview(othersMovieIndustryLbl)
        //creating othersMovieStory label to display movie story
        othersMovieStoryLbl.frame = CGRect(x: 30, y: 290, width: 380, height: 400)
        othersMovieStoryLbl.textColor = .black
        othersMovieStoryLbl.numberOfLines = 0
        //othersMovieStoryLbl.contentMode = .scaleToFill
        //othersMovieStoryLbl.sizeToFit()
        //error handling if movie story is unavailable
        if displyMovieDetailsInOVC!.story != nil{
            othersMovieStoryLbl.text = "Story : \(displyMovieDetailsInOVC!.story!)"
        }else{
            othersMovieStoryLbl.text = "Story : \(displyMovieDetailsInOVC!.title!) story is unavailable"
        }
        othersMovieInfoSC.contentSize = CGSize(width: view.frame.width, height: othersMovieStoryLbl.frame.maxY)
        othersMovieInfoSC.addSubview(othersMovieStoryLbl)
        //creatings songsView to display movie songs
        //creating a variable to increment view frame
        var val = 0
        for i in 0..<displyMovieDetailsInOVC!.songs!.count{
            //creating othersSongsView to display songs names and songsAVPVC
            othersSongsView = UIView()
            othersSongsView.frame = CGRect(x: 10, y: 30+val, width: 390, height: 80)
            othersSongsView.backgroundColor = .white
            othersSongsView.layer.cornerRadius = 13
            othersSongsScrollView.addSubview(othersSongsView)
            othersSongsViewArr.append(othersSongsView)
            val+=120
            //adding posters to songsImage
            var songPosterObj = URLSession.shared.dataTask(with:URL(string:"https://services.brninfotech.com/tws/\( displyMovieDetailsInOVC!.posters![0])".replacingOccurrences(of: " ", with: "%20"))!) { (posters, res1, err1) in
                if posters != nil{
                    //thread error handling
                    DispatchQueue.main.async {
                        //creating songs image for displaying in BMDVC view controller
                        self.othersMovieSongsImage = UIImageView(image: UIImage(data: posters!))
                        self.othersMovieSongsImage.frame = CGRect(x: 20, y: 10, width: 50, height: 50)
                        self.othersMovieSongsImage.contentMode = .scaleToFill
                        self.othersSongsViewArr[i].addSubview(self.othersMovieSongsImage)
                }
                }else{
                    print("posters are nil")
                }

            }
            //resuming songPosterObj
            songPosterObj.resume()
//        }else{
//
//        }
//            //creating othersSongsLbl for displaying song name
            othersSongsLbl = UILabel()
            othersSongsLbl.frame = CGRect(x: 90, y: 15, width: 230, height: 50)
            othersSongsLbl.text = "\(displyMovieDetailsInOVC!.songs![i].split(separator: "/")[3])"
            othersSongsLbl.textColor = view.backgroundColor
            othersSongsView.addSubview(othersSongsLbl)
            //creating AVPlayerViewController without controls
            othersSongswithoutControls = AVPlayerViewController()
            othersSongswithoutControls.view.frame = CGRect(x: 310, y: 15, width: 60, height: 50)
            othersSongswithoutControls.player = AVPlayer(url: URL(string: "https://services.brninfotech.com/tws/\(displyMovieDetailsInOVC!.songs![i])".replacingOccurrences(of: " ", with: "%20"))!)

            othersSongswithoutControls.view.backgroundColor = .white
            
            othersSongsView.addSubview(othersSongswithoutControls.view)
            othersSongswithoutControlsArr.append(othersSongswithoutControls)
        }
        othersSongsScrollView.contentSize = CGSize(width: view.frame.width, height: othersSongsView.frame.maxY+100)

    }
    //creating othersViewInfoSwipeUpAction function to change view frame
    @objc func othersViewInfoSwipeUpAction(){
        if othersMovieInfoViewSwipeUpGstr.direction == .up{
            othersMovieInfoView.frame = CGRect(x: 0, y: 160, width: view.frame.width+50, height: 900)
        }
    }
    //creating bwViewInfoSwipeUpAction function to change view frame
    @objc func othersViewInfoSwipeDownAction(){
        if othersMovieInfoViewSwipeUpGstr.direction == .up{
            othersMovieInfoView.frame = CGRect(x: 0, y: 600, width: view.frame.width+50, height: 900)
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeUpAction(){
        //changing view frame based on swipe up action
        if othersSongsViewSwipeUpGstr.direction == .up{
            othersMovieSongsView.frame = CGRect(x: 0, y: 245, width: view.frame.width+50, height: 900)
            print("swiped up")
        }
    }
    //creating swipe down guester action to movie info view
    @objc func songsInfoSwipeDownActio(){
        //changing view frame based on swipe down action
        if othersSongsViewSwipeDownGstr.direction == .down{
            othersMovieSongsView.frame = CGRect(x: 0, y: 685, width: view.frame.width+50, height: 900)
            print("swiped down")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
