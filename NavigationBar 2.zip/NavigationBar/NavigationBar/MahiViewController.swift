//
//  MahiViewController.swift
//  NavigationBar
//
//  Created by Lenovo on 06/02/21.
//

import UIKit

class MahiViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
